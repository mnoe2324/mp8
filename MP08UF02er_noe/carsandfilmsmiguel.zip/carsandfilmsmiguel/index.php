<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cars and Films</title>
    <link rel="stylesheet" href="css/stylez.css">
</head>
<body>
    <div class="cabecera">
        <h1><span style="color:black">cars</span><span style="color:grey">and</span><span style="color:black">films<span></h1>
    </div>
    <div class="imagengrande">
        <iframe src="anifeta/ani.html" width="100%" height="540px" frameborder="0"></iframe>
    </div>
    <div class="contenedor">
        <div class="celda uno"><h5>Pulp Fiction</h5></div>
        <div class="celda dos"><h5>Taxi Driver</h5></div>
        <div class="celda tres"><h5>Goldfinger</h5></div>
        <div class="celda cuatro"><h5>Ghost Busters</h5></div>
        <div class="celda cinco"><h5>Mr. Bean</h5></div>
        <div class="celda seis"><h5>Back to the Future</h5></div>
        <div class="celda siete"><h5>Knight Rider</h5></div>
        <div class="celda ocho"><h5>The A-Team</h5></div>
        <div class="celda nueve"><h5>Breaking Bad</h5></div>
    </div>
    <div class="pie"></div>
</body>
</html>